﻿Imports System.Data
Imports System.Configuration
Imports System.Data.SqlClient
Imports System.ServiceModel
Imports System.Runtime.Serialization

' NOTE: You can use the "Rename" command on the context menu to change the interface name "IProductService" in both code and config file together.
<ServiceContract()>
Public Interface IProductService

    <OperationContract()>
    Function GetProductList() As List(Of products_prices)
End Interface






