﻿Imports System.Data.SqlClient

' NOTE: You can use the "Rename" command on the context menu to change the class name "ProductService" in code, svc and config file together.
' NOTE: In order to launch WCF Test Client for testing this service, please select ProductService.svc or ProductService.svc.vb at the Solution Explorer and start debugging.
Public Class ProductService
    Implements IProductService
    Public Function GetProductList() As List(Of products_prices) Implements IProductService.GetProductList
        Dim dataContext As trialdbEntities = New trialdbEntities
        Return dataContext.products_prices.ToList
    End Function
End Class
