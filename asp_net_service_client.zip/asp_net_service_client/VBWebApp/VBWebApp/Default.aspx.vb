﻿Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports VBWebApp.ProductServiceReference




Public Class _Default
    Inherits System.Web.UI.Page

    Dim p As Object

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim client As New ProductServiceReference.ProductServiceClient()
        GridView1.DataSource = client.GetProductList()
        GridView1.DataBind()


    End Sub
End Class